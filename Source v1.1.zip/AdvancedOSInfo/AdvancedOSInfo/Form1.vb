﻿Imports System.IO
Imports System.Text
Public Class Form1
    Dim Regpath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    Dim RegPath2 = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinSAT"
    Dim RegPath3 = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Environment"

    Dim BuildBranchText = "Build Branch: " + My.Computer.Registry.GetValue(Regpath, "BuildBranch", Nothing)
    Dim BuildLabText = "Build Lab: " + My.Computer.Registry.GetValue(Regpath, "BuildLab", Nothing)
    Dim BuildLabExText = "Build Lab Ex: " + My.Computer.Registry.GetValue(Regpath, "BuildLabEx", Nothing)
    Dim CompositionEditionIDText = "Composition Edition ID: " + My.Computer.Registry.GetValue(Regpath, "CompositionEditionID", Nothing)
    Dim CurrentBuildText = "Current Build: " + My.Computer.Registry.GetValue(Regpath, "CurrentBuild", Nothing)
    Dim CurrentTypeText = "Current Type: " + My.Computer.Registry.GetValue(Regpath, "CurrentType", Nothing)
    Dim CurrentVersionText = "Current Version: " + My.Computer.Registry.GetValue(Regpath, "CurrentVersion", Nothing)
    Dim DisplayVersionText = "Display Version: " + My.Computer.Registry.GetValue(Regpath, "DisplayVersion", Nothing)
    Dim EditionIDText = "Edition ID: " + My.Computer.Registry.GetValue(Regpath, "EditionID", Nothing)
    Dim InstallationTypeText = "Installation Type: " + My.Computer.Registry.GetValue(Regpath, "InstallationType", Nothing)
    Dim PathNameText = "Path Name: " + My.Computer.Registry.GetValue(Regpath, "PathName", Nothing)
    Dim ProductIdText = "Product Id: " + My.Computer.Registry.GetValue(Regpath, "ProductId", Nothing)
    Dim ProductNameText = "Product Name: " + My.Computer.Registry.GetValue(Regpath, "ProductName", Nothing)
    Dim RegisteredOrganizationText = "Registered Organization: " + My.Computer.Registry.GetValue(Regpath, "RegisteredOrganization", Nothing)
    Dim RegisteredOwnerText = "Registered Owner: " + My.Computer.Registry.GetValue(Regpath, "RegisteredOwner", Nothing)
    Dim ReleaseIdText = "Release Id: " + My.Computer.Registry.GetValue(Regpath, "ReleaseId", Nothing)
    Dim ProcessorIdentifier = "CPU Identifier: " + My.Computer.Registry.GetValue(RegPath3, "PROCESSOR_IDENTIFIER", Nothing)
    Dim ProcessorArchitecture = "CPU Architecture: " + My.Computer.Registry.GetValue(RegPath3, "PROCESSOR_ARCHITECTURE", Nothing)
    Dim ProcessorLevel = "CPU Level: " + My.Computer.Registry.GetValue(RegPath3, "PROCESSOR_LEVEL", Nothing)
    Dim ProcessorRevision = "CPU Revision: " + My.Computer.Registry.GetValue(RegPath3, "PROCESSOR_REVISION", Nothing)
    Dim Cores = "CPU Cores: " + My.Computer.Registry.GetValue(RegPath3, "NUMBER_OF_PROCESSORS", Nothing)
    Dim TempPath = "Temp Path: " + My.Computer.Registry.GetValue(RegPath3, "TEMP", Nothing)
    Dim RegisteredOrganizationLog As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OSPlataform.Text = "OS Plataform: " + My.Computer.Info.OSPlatform
        OSFullName.Text = "OS Full Name: " + My.Computer.Info.OSFullName
        OSVersion.Text = "OS Version: " + My.Computer.Info.OSVersion
        BuildBranch.Text = BuildBranchText
        BuildLab.Text = BuildLabText
        BuildLabEx.Text = BuildLabExText
        CurrentBuild.Text = CurrentBuildText
        CurrentType.Text = CurrentTypeText
        CurrentVersion.Text = CurrentVersionText
        DisplayVersion.Text = DisplayVersionText
        InstallationType.Text = InstallationTypeText
        PathName.Text = PathNameText
        ProductId.Text = ProductIdText
        ProductName.Text = ProductNameText
        RegisteredOwner.Text = RegisteredOwnerText
        ReleaseId.Text = ReleaseIdText
        EditionID.Text = EditionIDText
        CompositionEditionID.Text = CompositionEditionIDText
        TotalPhysicalMemory.Text = My.Computer.Info.TotalPhysicalMemory
        TotalVirtualMemory.Text = My.Computer.Info.TotalVirtualMemory
        AvailablePhysicalMemory.Text = My.Computer.Info.AvailablePhysicalMemory
        AvailableVirtualMemory.Text = My.Computer.Info.AvailableVirtualMemory
        ComputerName.Text = "Computer Name: " + My.Computer.Name
        BitsPerPixel.Text = My.Computer.Screen.BitsPerPixel
        Primary.Text = My.Computer.Screen.Primary
        GmtTime.Text = "Clock Gmt Time: " + My.Computer.Clock.GmtTime
        LocalTime.Text = "Clock Local Time: " + My.Computer.Clock.LocalTime
        TickCount.Text = My.Computer.Clock.TickCount
        ProcessorIdentifierLabel.Text = ProcessorIdentifier
        ProcessorArchitectureLabel.Text = ProcessorArchitecture
        ProcessorLevelLabel.Text = ProcessorLevel
        ProcessorRevisionLabel.Text = ProcessorRevision
        CoresLabel.Text = Cores
        TempPathLabel.Text = TempPath

        If My.Computer.Registry.GetValue(Regpath, "RegisteredOrganization", Nothing) = "" Then
            RegisteredOrganization.Hide()
            RegisteredOrganizationLog = ""
        Else
            RegisteredOrganization.Text = RegisteredOrganizationText
            RegisteredOrganizationLog = vbCrLf + RegisteredOrganization.Text
        End If

        If My.Computer.Network.IsAvailable = "True" Then
            IsNetworkAvailable.Text = "Is Network Available: True"
        Else
            IsNetworkAvailable.Text = "Is Network Available: False"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Restart()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim currentdate As String = DateTime.Now.ToLongDateString()
        Dim currenttime As String = DateTime.Now.ToString("hh:mm:ss")
        Dim path As String = "\" + "log_" + DateTime.Now.ToString("dd-mm-yy" + "_" + "hh-mm-ss") + ".txt"
        Dim logcontents As String = "Advanced OS Info v1.1 Log File - Date & time created: " + currentdate + " " + currenttime + vbCrLf _
            + vbCrLf + OSPlataform.Text _
            + vbCrLf + OSFullName.Text _
            + vbCrLf + OSVersion.Text _
            + vbCrLf + BuildBranch.Text _
            + vbCrLf + BuildLab.Text _
            + vbCrLf + BuildLabEx.Text _
            + vbCrLf + CurrentBuild.Text _
            + vbCrLf + CurrentType.Text _
            + vbCrLf + CurrentVersion.Text _
            + vbCrLf + DisplayVersion.Text _
            + vbCrLf + InstallationType.Text _
            + vbCrLf + PathName.Text _
            + vbCrLf + ProductId.Text _
            + vbCrLf + ProductName.Text _
            + vbCrLf + RegisteredOwner.Text _
            + vbCrLf + ReleaseId.Text _
            + vbCrLf + EditionID.Text _
            + vbCrLf + CompositionEditionID.Text _
            + vbCrLf + "Total Physical Memory (Bytes): " + TotalPhysicalMemory.Text _
            + vbCrLf + "Total Virtual Memory (Bytes): " + TotalVirtualMemory.Text _
            + vbCrLf + "Available Physical Memory (Bytes): " + AvailablePhysicalMemory.Text _
            + vbCrLf + "Available Virtual Memory (Bytes): " + AvailableVirtualMemory.Text _
            + vbCrLf + ComputerName.Text _
            + vbCrLf + "Screen Bits Per Pixel: " + BitsPerPixel.Text _
            + vbCrLf + "Screen Primary: " + Primary.Text _
            + vbCrLf + GmtTime.Text _
            + vbCrLf + LocalTime.Text _
            + vbCrLf + "Clock Tick Count (miliseconds): " + TickCount.Text _
            + RegisteredOrganizationLog _
            + vbCrLf + IsNetworkAvailable.Text _
            + vbCrLf + ProcessorIdentifierLabel.Text _
            + vbCrLf + ProcessorArchitectureLabel.Text _
            + vbCrLf + ProcessorLevelLabel.Text _
            + vbCrLf + ProcessorRevisionLabel.Text _
            + vbCrLf + CoresLabel.Text _
            + vbCrLf + TempPathLabel.Text

        ' Create or overwrite the file.
        Dim fs As FileStream = File.Create(path)

        ' Add text to the file.
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(logcontents)
        fs.Write(info, 0, info.Length)
        fs.Close()

        Dim opcion As DialogResult
        opcion = MessageBox.Show("Log file created in C:\",
                                 "Create Log File",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information)
    End Sub
End Class
