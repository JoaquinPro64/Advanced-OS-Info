﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.OSPlataform = New System.Windows.Forms.Label()
        Me.OSFullName = New System.Windows.Forms.Label()
        Me.OSVersion = New System.Windows.Forms.Label()
        Me.BuildBranch = New System.Windows.Forms.Label()
        Me.BuildLab = New System.Windows.Forms.Label()
        Me.BuildLabEx = New System.Windows.Forms.Label()
        Me.CompositionEditionID = New System.Windows.Forms.Label()
        Me.CurrentType = New System.Windows.Forms.Label()
        Me.CurrentVersion = New System.Windows.Forms.Label()
        Me.DisplayVersion = New System.Windows.Forms.Label()
        Me.EditionID = New System.Windows.Forms.Label()
        Me.InstallationType = New System.Windows.Forms.Label()
        Me.PathName = New System.Windows.Forms.Label()
        Me.ProductId = New System.Windows.Forms.Label()
        Me.ProductName = New System.Windows.Forms.Label()
        Me.RegisteredOrganization = New System.Windows.Forms.Label()
        Me.RegisteredOwner = New System.Windows.Forms.Label()
        Me.ReleaseId = New System.Windows.Forms.Label()
        Me.CurrentBuild = New System.Windows.Forms.Label()
        Me.ComputerName = New System.Windows.Forms.Label()
        Me.IsNetworkAvailable = New System.Windows.Forms.Label()
        Me.TotalPhysicalMemory = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TotalVirtualMemory = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.AvailablePhysicalMemory = New System.Windows.Forms.Label()
        Me.AvailableVirtualMemory = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BitsPerPixel = New System.Windows.Forms.Label()
        Me.Primary = New System.Windows.Forms.Label()
        Me.GmtTime = New System.Windows.Forms.Label()
        Me.LocalTime = New System.Windows.Forms.Label()
        Me.TickCount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TempPathLabel = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.CoresLabel = New System.Windows.Forms.Label()
        Me.ProcessorRevisionLabel = New System.Windows.Forms.Label()
        Me.ProcessorLevelLabel = New System.Windows.Forms.Label()
        Me.ProcessorArchitectureLabel = New System.Windows.Forms.Label()
        Me.ProcessorIdentifierLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'OSPlataform
        '
        Me.OSPlataform.AutoSize = True
        Me.OSPlataform.Location = New System.Drawing.Point(6, 199)
        Me.OSPlataform.Name = "OSPlataform"
        Me.OSPlataform.Size = New System.Drawing.Size(77, 15)
        Me.OSPlataform.TabIndex = 0
        Me.OSPlataform.Text = "OS Plataform"
        '
        'OSFullName
        '
        Me.OSFullName.AutoSize = True
        Me.OSFullName.Location = New System.Drawing.Point(6, 169)
        Me.OSFullName.Name = "OSFullName"
        Me.OSFullName.Size = New System.Drawing.Size(79, 15)
        Me.OSFullName.TabIndex = 1
        Me.OSFullName.Text = "OS Full Name"
        '
        'OSVersion
        '
        Me.OSVersion.AutoSize = True
        Me.OSVersion.Location = New System.Drawing.Point(6, 184)
        Me.OSVersion.Name = "OSVersion"
        Me.OSVersion.Size = New System.Drawing.Size(63, 15)
        Me.OSVersion.TabIndex = 2
        Me.OSVersion.Text = "OS Version"
        '
        'BuildBranch
        '
        Me.BuildBranch.AutoSize = True
        Me.BuildBranch.Location = New System.Drawing.Point(6, 19)
        Me.BuildBranch.Name = "BuildBranch"
        Me.BuildBranch.Size = New System.Drawing.Size(74, 15)
        Me.BuildBranch.TabIndex = 3
        Me.BuildBranch.Text = "Build Branch"
        '
        'BuildLab
        '
        Me.BuildLab.AutoSize = True
        Me.BuildLab.Location = New System.Drawing.Point(6, 34)
        Me.BuildLab.Name = "BuildLab"
        Me.BuildLab.Size = New System.Drawing.Size(56, 15)
        Me.BuildLab.TabIndex = 4
        Me.BuildLab.Text = "Build Lab"
        '
        'BuildLabEx
        '
        Me.BuildLabEx.AutoSize = True
        Me.BuildLabEx.Location = New System.Drawing.Point(6, 49)
        Me.BuildLabEx.Name = "BuildLabEx"
        Me.BuildLabEx.Size = New System.Drawing.Size(65, 15)
        Me.BuildLabEx.TabIndex = 5
        Me.BuildLabEx.Text = "BuildLabEx"
        '
        'CompositionEditionID
        '
        Me.CompositionEditionID.AutoSize = True
        Me.CompositionEditionID.Location = New System.Drawing.Point(6, 109)
        Me.CompositionEditionID.Name = "CompositionEditionID"
        Me.CompositionEditionID.Size = New System.Drawing.Size(130, 15)
        Me.CompositionEditionID.TabIndex = 6
        Me.CompositionEditionID.Text = "Composition Edition ID"
        '
        'CurrentType
        '
        Me.CurrentType.AutoSize = True
        Me.CurrentType.Location = New System.Drawing.Point(6, 94)
        Me.CurrentType.Name = "CurrentType"
        Me.CurrentType.Size = New System.Drawing.Size(74, 15)
        Me.CurrentType.TabIndex = 7
        Me.CurrentType.Text = "Current Type"
        '
        'CurrentVersion
        '
        Me.CurrentVersion.AutoSize = True
        Me.CurrentVersion.Location = New System.Drawing.Point(6, 79)
        Me.CurrentVersion.Name = "CurrentVersion"
        Me.CurrentVersion.Size = New System.Drawing.Size(88, 15)
        Me.CurrentVersion.TabIndex = 8
        Me.CurrentVersion.Text = "Current Version"
        '
        'DisplayVersion
        '
        Me.DisplayVersion.AutoSize = True
        Me.DisplayVersion.Location = New System.Drawing.Point(6, 124)
        Me.DisplayVersion.Name = "DisplayVersion"
        Me.DisplayVersion.Size = New System.Drawing.Size(86, 15)
        Me.DisplayVersion.TabIndex = 9
        Me.DisplayVersion.Text = "Display Version"
        '
        'EditionID
        '
        Me.EditionID.AutoSize = True
        Me.EditionID.Location = New System.Drawing.Point(6, 139)
        Me.EditionID.Name = "EditionID"
        Me.EditionID.Size = New System.Drawing.Size(58, 15)
        Me.EditionID.TabIndex = 10
        Me.EditionID.Text = "Edition ID"
        '
        'InstallationType
        '
        Me.InstallationType.AutoSize = True
        Me.InstallationType.Location = New System.Drawing.Point(6, 154)
        Me.InstallationType.Name = "InstallationType"
        Me.InstallationType.Size = New System.Drawing.Size(92, 15)
        Me.InstallationType.TabIndex = 11
        Me.InstallationType.Text = "Installation Type"
        '
        'PathName
        '
        Me.PathName.AutoSize = True
        Me.PathName.Location = New System.Drawing.Point(6, 229)
        Me.PathName.Name = "PathName"
        Me.PathName.Size = New System.Drawing.Size(66, 15)
        Me.PathName.TabIndex = 12
        Me.PathName.Text = "Path Name"
        '
        'ProductId
        '
        Me.ProductId.AutoSize = True
        Me.ProductId.Location = New System.Drawing.Point(6, 214)
        Me.ProductId.Name = "ProductId"
        Me.ProductId.Size = New System.Drawing.Size(62, 15)
        Me.ProductId.TabIndex = 13
        Me.ProductId.Text = "Product Id"
        '
        'ProductName
        '
        Me.ProductName.AutoSize = True
        Me.ProductName.Location = New System.Drawing.Point(6, 244)
        Me.ProductName.Name = "ProductName"
        Me.ProductName.Size = New System.Drawing.Size(84, 15)
        Me.ProductName.TabIndex = 14
        Me.ProductName.Text = "Product Name"
        '
        'RegisteredOrganization
        '
        Me.RegisteredOrganization.AutoSize = True
        Me.RegisteredOrganization.Location = New System.Drawing.Point(6, 303)
        Me.RegisteredOrganization.Name = "RegisteredOrganization"
        Me.RegisteredOrganization.Size = New System.Drawing.Size(133, 15)
        Me.RegisteredOrganization.TabIndex = 15
        Me.RegisteredOrganization.Text = "Registered Organization"
        '
        'RegisteredOwner
        '
        Me.RegisteredOwner.AutoSize = True
        Me.RegisteredOwner.Location = New System.Drawing.Point(6, 288)
        Me.RegisteredOwner.Name = "RegisteredOwner"
        Me.RegisteredOwner.Size = New System.Drawing.Size(100, 15)
        Me.RegisteredOwner.TabIndex = 16
        Me.RegisteredOwner.Text = "Registered Owner"
        '
        'ReleaseId
        '
        Me.ReleaseId.AutoSize = True
        Me.ReleaseId.Location = New System.Drawing.Point(6, 259)
        Me.ReleaseId.Name = "ReleaseId"
        Me.ReleaseId.Size = New System.Drawing.Size(59, 15)
        Me.ReleaseId.TabIndex = 17
        Me.ReleaseId.Text = "Release Id"
        '
        'CurrentBuild
        '
        Me.CurrentBuild.AutoSize = True
        Me.CurrentBuild.Location = New System.Drawing.Point(6, 64)
        Me.CurrentBuild.Name = "CurrentBuild"
        Me.CurrentBuild.Size = New System.Drawing.Size(77, 15)
        Me.CurrentBuild.TabIndex = 19
        Me.CurrentBuild.Text = "Current Build"
        '
        'ComputerName
        '
        Me.ComputerName.AutoSize = True
        Me.ComputerName.Location = New System.Drawing.Point(6, 18)
        Me.ComputerName.Name = "ComputerName"
        Me.ComputerName.Size = New System.Drawing.Size(96, 15)
        Me.ComputerName.TabIndex = 20
        Me.ComputerName.Text = "Computer Name"
        '
        'IsNetworkAvailable
        '
        Me.IsNetworkAvailable.AutoSize = True
        Me.IsNetworkAvailable.Location = New System.Drawing.Point(6, 33)
        Me.IsNetworkAvailable.Name = "IsNetworkAvailable"
        Me.IsNetworkAvailable.Size = New System.Drawing.Size(114, 15)
        Me.IsNetworkAvailable.TabIndex = 21
        Me.IsNetworkAvailable.Text = "Is Network Available"
        '
        'TotalPhysicalMemory
        '
        Me.TotalPhysicalMemory.AutoSize = True
        Me.TotalPhysicalMemory.Location = New System.Drawing.Point(173, 49)
        Me.TotalPhysicalMemory.Name = "TotalPhysicalMemory"
        Me.TotalPhysicalMemory.Size = New System.Drawing.Size(47, 15)
        Me.TotalPhysicalMemory.TabIndex = 22
        Me.TotalPhysicalMemory.Text = "VarTPM"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 15)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Total Physical Memory (Bytes):"
        '
        'TotalVirtualMemory
        '
        Me.TotalVirtualMemory.AutoSize = True
        Me.TotalVirtualMemory.Location = New System.Drawing.Point(163, 64)
        Me.TotalVirtualMemory.Name = "TotalVirtualMemory"
        Me.TotalVirtualMemory.Size = New System.Drawing.Size(47, 15)
        Me.TotalVirtualMemory.TabIndex = 24
        Me.TotalVirtualMemory.Text = "VarTVM"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(159, 15)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Total Virtual Memory (Bytes):"
        '
        'AvailablePhysicalMemory
        '
        Me.AvailablePhysicalMemory.AutoSize = True
        Me.AvailablePhysicalMemory.Location = New System.Drawing.Point(194, 19)
        Me.AvailablePhysicalMemory.Name = "AvailablePhysicalMemory"
        Me.AvailablePhysicalMemory.Size = New System.Drawing.Size(49, 15)
        Me.AvailablePhysicalMemory.TabIndex = 26
        Me.AvailablePhysicalMemory.Text = "VarAPM"
        '
        'AvailableVirtualMemory
        '
        Me.AvailableVirtualMemory.AutoSize = True
        Me.AvailableVirtualMemory.Location = New System.Drawing.Point(185, 34)
        Me.AvailableVirtualMemory.Name = "AvailableVirtualMemory"
        Me.AvailableVirtualMemory.Size = New System.Drawing.Size(48, 15)
        Me.AvailableVirtualMemory.TabIndex = 27
        Me.AvailableVirtualMemory.Text = "VarAVM"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(191, 15)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Available Physical Memory (Bytes):"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 34)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(182, 15)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Available Virtual Memory (Bytes):"
        '
        'BitsPerPixel
        '
        Me.BitsPerPixel.AutoSize = True
        Me.BitsPerPixel.Location = New System.Drawing.Point(118, 34)
        Me.BitsPerPixel.Name = "BitsPerPixel"
        Me.BitsPerPixel.Size = New System.Drawing.Size(44, 15)
        Me.BitsPerPixel.TabIndex = 30
        Me.BitsPerPixel.Text = "VarBPP"
        '
        'Primary
        '
        Me.Primary.AutoSize = True
        Me.Primary.Location = New System.Drawing.Point(92, 19)
        Me.Primary.Name = "Primary"
        Me.Primary.Size = New System.Drawing.Size(30, 15)
        Me.Primary.TabIndex = 32
        Me.Primary.Text = "VarP"
        '
        'GmtTime
        '
        Me.GmtTime.AutoSize = True
        Me.GmtTime.Location = New System.Drawing.Point(6, 19)
        Me.GmtTime.Name = "GmtTime"
        Me.GmtTime.Size = New System.Drawing.Size(89, 15)
        Me.GmtTime.TabIndex = 33
        Me.GmtTime.Text = "Clock GmtTime"
        '
        'LocalTime
        '
        Me.LocalTime.AutoSize = True
        Me.LocalTime.Location = New System.Drawing.Point(6, 34)
        Me.LocalTime.Name = "LocalTime"
        Me.LocalTime.Size = New System.Drawing.Size(94, 15)
        Me.LocalTime.TabIndex = 34
        Me.LocalTime.Text = "Clock LocalTime"
        '
        'TickCount
        '
        Me.TickCount.AutoSize = True
        Me.TickCount.Location = New System.Drawing.Point(177, 49)
        Me.TickCount.Name = "TickCount"
        Me.TickCount.Size = New System.Drawing.Size(36, 15)
        Me.TickCount.TabIndex = 35
        Me.TickCount.Text = "VarTC"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(115, 15)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = "Screen Bits Per Pixel:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 15)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Screen Primary:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 49)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(174, 15)
        Me.Label7.TabIndex = 38
        Me.Label7.Text = "Clock Tick Count (miliseconds):"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GmtTime)
        Me.GroupBox1.Controls.Add(Me.LocalTime)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.TickCount)
        Me.GroupBox1.Location = New System.Drawing.Point(368, 222)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(420, 71)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Time"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Primary)
        Me.GroupBox2.Controls.Add(Me.BitsPerPixel)
        Me.GroupBox2.Location = New System.Drawing.Point(368, 164)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(420, 54)
        Me.GroupBox2.TabIndex = 41
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Screen"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.TotalVirtualMemory)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.AvailablePhysicalMemory)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.AvailableVirtualMemory)
        Me.GroupBox3.Controls.Add(Me.TotalPhysicalMemory)
        Me.GroupBox3.Location = New System.Drawing.Point(368, 70)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(420, 88)
        Me.GroupBox3.TabIndex = 42
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "RAM"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TempPathLabel)
        Me.GroupBox4.Controls.Add(Me.OSPlataform)
        Me.GroupBox4.Controls.Add(Me.OSFullName)
        Me.GroupBox4.Controls.Add(Me.OSVersion)
        Me.GroupBox4.Controls.Add(Me.BuildBranch)
        Me.GroupBox4.Controls.Add(Me.BuildLab)
        Me.GroupBox4.Controls.Add(Me.BuildLabEx)
        Me.GroupBox4.Controls.Add(Me.CompositionEditionID)
        Me.GroupBox4.Controls.Add(Me.ReleaseId)
        Me.GroupBox4.Controls.Add(Me.CurrentBuild)
        Me.GroupBox4.Controls.Add(Me.CurrentType)
        Me.GroupBox4.Controls.Add(Me.CurrentVersion)
        Me.GroupBox4.Controls.Add(Me.RegisteredOrganization)
        Me.GroupBox4.Controls.Add(Me.RegisteredOwner)
        Me.GroupBox4.Controls.Add(Me.DisplayVersion)
        Me.GroupBox4.Controls.Add(Me.EditionID)
        Me.GroupBox4.Controls.Add(Me.ProductName)
        Me.GroupBox4.Controls.Add(Me.InstallationType)
        Me.GroupBox4.Controls.Add(Me.ProductId)
        Me.GroupBox4.Controls.Add(Me.PathName)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(356, 328)
        Me.GroupBox4.TabIndex = 43
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "OS"
        '
        'TempPathLabel
        '
        Me.TempPathLabel.AutoSize = True
        Me.TempPathLabel.Location = New System.Drawing.Point(6, 274)
        Me.TempPathLabel.Name = "TempPathLabel"
        Me.TempPathLabel.Size = New System.Drawing.Size(63, 15)
        Me.TempPathLabel.TabIndex = 20
        Me.TempPathLabel.Text = "Temp Path"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ComputerName)
        Me.GroupBox5.Controls.Add(Me.IsNetworkAvailable)
        Me.GroupBox5.Location = New System.Drawing.Point(368, 12)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(420, 56)
        Me.GroupBox5.TabIndex = 44
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "PC General"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(26, 352)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(95, 23)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "Create log file"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(259, 352)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "Refresh"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.CoresLabel)
        Me.GroupBox6.Controls.Add(Me.ProcessorRevisionLabel)
        Me.GroupBox6.Controls.Add(Me.ProcessorLevelLabel)
        Me.GroupBox6.Controls.Add(Me.ProcessorArchitectureLabel)
        Me.GroupBox6.Controls.Add(Me.ProcessorIdentifierLabel)
        Me.GroupBox6.Location = New System.Drawing.Point(368, 296)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(420, 96)
        Me.GroupBox6.TabIndex = 47
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "CPU"
        '
        'CoresLabel
        '
        Me.CoresLabel.AutoSize = True
        Me.CoresLabel.Location = New System.Drawing.Point(6, 78)
        Me.CoresLabel.Name = "CoresLabel"
        Me.CoresLabel.Size = New System.Drawing.Size(37, 15)
        Me.CoresLabel.TabIndex = 4
        Me.CoresLabel.Text = "Cores"
        '
        'ProcessorRevisionLabel
        '
        Me.ProcessorRevisionLabel.AutoSize = True
        Me.ProcessorRevisionLabel.Location = New System.Drawing.Point(6, 64)
        Me.ProcessorRevisionLabel.Name = "ProcessorRevisionLabel"
        Me.ProcessorRevisionLabel.Size = New System.Drawing.Size(105, 15)
        Me.ProcessorRevisionLabel.TabIndex = 3
        Me.ProcessorRevisionLabel.Text = "Processor Revision"
        '
        'ProcessorLevelLabel
        '
        Me.ProcessorLevelLabel.AutoSize = True
        Me.ProcessorLevelLabel.Location = New System.Drawing.Point(6, 49)
        Me.ProcessorLevelLabel.Name = "ProcessorLevelLabel"
        Me.ProcessorLevelLabel.Size = New System.Drawing.Size(88, 15)
        Me.ProcessorLevelLabel.TabIndex = 2
        Me.ProcessorLevelLabel.Text = "Processor Level"
        '
        'ProcessorArchitectureLabel
        '
        Me.ProcessorArchitectureLabel.AutoSize = True
        Me.ProcessorArchitectureLabel.Location = New System.Drawing.Point(6, 34)
        Me.ProcessorArchitectureLabel.Name = "ProcessorArchitectureLabel"
        Me.ProcessorArchitectureLabel.Size = New System.Drawing.Size(126, 15)
        Me.ProcessorArchitectureLabel.TabIndex = 1
        Me.ProcessorArchitectureLabel.Text = "Processor Architecture"
        '
        'ProcessorIdentifierLabel
        '
        Me.ProcessorIdentifierLabel.AutoSize = True
        Me.ProcessorIdentifierLabel.Location = New System.Drawing.Point(6, 19)
        Me.ProcessorIdentifierLabel.Name = "ProcessorIdentifierLabel"
        Me.ProcessorIdentifierLabel.Size = New System.Drawing.Size(108, 15)
        Me.ProcessorIdentifierLabel.TabIndex = 0
        Me.ProcessorIdentifierLabel.Text = "Processor Identifier"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 397)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Advanced OS Info v1.1 - JoaquinPro64 2022"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents OSPlataform As Label
    Friend WithEvents OSFullName As Label
    Friend WithEvents OSVersion As Label
    Friend WithEvents BuildBranch As Label
    Friend WithEvents BuildLab As Label
    Friend WithEvents BuildLabEx As Label
    Friend WithEvents CompositionEditionID As Label
    Friend WithEvents CurrentType As Label
    Friend WithEvents CurrentVersion As Label
    Friend WithEvents DisplayVersion As Label
    Friend WithEvents EditionID As Label
    Friend WithEvents InstallationType As Label
    Friend WithEvents PathName As Label
    Friend WithEvents ProductId As Label
    Friend WithEvents ProductName As Label
    Friend WithEvents RegisteredOrganization As Label
    Friend WithEvents RegisteredOwner As Label
    Friend WithEvents ReleaseId As Label
    Friend WithEvents PrimaryAdapterString As Label
    Friend WithEvents CurrentBuild As Label
    Friend WithEvents ComputerName As Label
    Friend WithEvents IsNetworkAvailable As Label
    Friend WithEvents TotalPhysicalMemory As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TotalVirtualMemory As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents AvailablePhysicalMemory As Label
    Friend WithEvents AvailableVirtualMemory As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BitsPerPixel As Label
    Friend WithEvents Primary As Label
    Friend WithEvents GmtTime As Label
    Friend WithEvents LocalTime As Label
    Friend WithEvents TickCount As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents TempPathLabel As Label
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents CoresLabel As Label
    Friend WithEvents ProcessorRevisionLabel As Label
    Friend WithEvents ProcessorLevelLabel As Label
    Friend WithEvents ProcessorArchitectureLabel As Label
    Friend WithEvents ProcessorIdentifierLabel As Label
End Class
