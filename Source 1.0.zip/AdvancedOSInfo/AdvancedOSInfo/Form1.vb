﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim Regpath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
        Dim RegPath2 = "Equipo\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinSAT"

        Dim BuildBranchText = "Build Branch: " + My.Computer.Registry.GetValue(Regpath, "BuildBranch", Nothing)
        Dim BuildLabText = "Build Lab: " + My.Computer.Registry.GetValue(Regpath, "BuildLab", Nothing)
        Dim BuildLabExText = "Build Lab Ex: " + My.Computer.Registry.GetValue(Regpath, "BuildLabEx", Nothing)
        Dim CompositionEditionIDText = "Composition Edition ID: " + My.Computer.Registry.GetValue(Regpath, "CompositionEditionID", Nothing)
        Dim CurrentBuildText = "Current Build: " + My.Computer.Registry.GetValue(Regpath, "CurrentBuild", Nothing)
        Dim CurrentTypeText = "Current Type: " + My.Computer.Registry.GetValue(Regpath, "CurrentType", Nothing)
        Dim CurrentVersionText = "Current Version: " + My.Computer.Registry.GetValue(Regpath, "CurrentVersion", Nothing)
        Dim DisplayVersionText = "Display Version: " + My.Computer.Registry.GetValue(Regpath, "DisplayVersion", Nothing)
        Dim EditionIDText = "Edition ID: " + My.Computer.Registry.GetValue(Regpath, "EditionID", Nothing)
        Dim InstallationTypeText = "Installation Type: " + My.Computer.Registry.GetValue(Regpath, "InstallationType", Nothing)
        Dim PathNameText = "Path Name: " + My.Computer.Registry.GetValue(Regpath, "PathName", Nothing)
        Dim ProductIdText = "Product Id: " + My.Computer.Registry.GetValue(Regpath, "ProductId", Nothing)
        Dim ProductNameText = "Product Name: " + My.Computer.Registry.GetValue(Regpath, "ProductName", Nothing)
        Dim RegisteredOrganizationText = "Registered Organization: " + My.Computer.Registry.GetValue(Regpath, "RegisteredOrganization", Nothing)
        Dim RegisteredOwnerText = "Registered Owner: " + My.Computer.Registry.GetValue(Regpath, "RegisteredOwner", Nothing)
        Dim ReleaseIdText = "Release Id: " + My.Computer.Registry.GetValue(Regpath, "ReleaseId", Nothing)

        OSPlataform.Text = "OS Plataform: " + My.Computer.Info.OSPlatform
        OSFullName.Text = "OS Full Name: " + My.Computer.Info.OSFullName
        OSVersion.Text = "OS Version: " + My.Computer.Info.OSVersion
        BuildBranch.Text = BuildBranchText
        BuildLab.Text = BuildLabText
        BuildLabEx.Text = BuildLabExText
        CurrentBuild.Text = CurrentBuildText
        CurrentType.Text = CurrentTypeText
        CurrentVersion.Text = CurrentVersionText
        DisplayVersion.Text = DisplayVersionText
        InstallationType.Text = InstallationTypeText
        PathName.Text = PathNameText
        ProductId.Text = ProductIdText
        ProductName.Text = ProductNameText
        RegisteredOwner.Text = RegisteredOwnerText
        ReleaseId.Text = ReleaseIdText
        EditionID.Text = EditionIDText
        CompositionEditionID.Text = CompositionEditionIDText
        TotalPhysicalMemory.Text = My.Computer.Info.TotalPhysicalMemory
        TotalVirtualMemory.Text = My.Computer.Info.TotalVirtualMemory
        AvailablePhysicalMemory.Text = My.Computer.Info.AvailablePhysicalMemory
        AvailableVirtualMemory.Text = My.Computer.Info.AvailableVirtualMemory
        ComputerName.Text = "Computer Name: " + My.Computer.Name
        BitsPerPixel.Text = My.Computer.Screen.BitsPerPixel
        Primary.Text = My.Computer.Screen.Primary
        GmtTime.Text = "Clock Gmt Time: " + My.Computer.Clock.GmtTime
        LocalTime.Text = "Clock Local Time: " + My.Computer.Clock.LocalTime
        TickCount.Text = My.Computer.Clock.TickCount

        If My.Computer.Registry.GetValue(Regpath, "RegisteredOrganization", Nothing) = "" Then
            RegisteredOrganization.Hide()
        Else
            RegisteredOrganization.Text = RegisteredOrganizationText
        End If

        If My.Computer.Network.IsAvailable = "True" Then
            IsNetworkAvailable.Text = "Is Network Available: True"
        Else
            IsNetworkAvailable.Text = "Is Network Available: False"
        End If

    End Sub

    Private Sub Form1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        If (e.KeyCode.F5) Then
            Application.Restart()
        End If

    End Sub
End Class
